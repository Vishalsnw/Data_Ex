# DealHunter - E-commerce Deal Aggregator

## Overview

DealHunter is a web application that aggregates and displays discount deals from multiple e-commerce platforms (Amazon, Flipkart, Myntra, and Meesho). The application provides users with a centralized platform to discover the best deals across different shopping platforms, with advanced filtering, sorting, and search capabilities.

The application is built as a full-stack TypeScript application with a React frontend and Express backend, designed to scrape and display deals with real-time updates and comprehensive filtering options.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theming and CSS variables

**Design Patterns:**
- Component-based architecture with reusable UI components
- Custom hooks for shared logic (mobile detection, toast notifications)
- Separation of concerns with dedicated components for deals, filters, and statistics
- Query-based data fetching with automatic caching and invalidation

**Key Frontend Features:**
- Responsive grid and list view modes for deal display
- Real-time filtering by platform, category, discount percentage, and price range
- Advanced sorting options (by discount, price, platform, date)
- Pagination for large datasets
- Statistics dashboard showing total deals, average discounts, and platform coverage

### Backend Architecture

**Technology Stack:**
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: Neon Database (serverless PostgreSQL)
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions

**API Design:**
- RESTful API endpoints for deal operations
- GET `/api/deals` - Retrieve deals with filtering and pagination
- GET `/api/deals/stats` - Get aggregated statistics
- GET `/api/deals/:id` - Retrieve individual deal details
- POST `/api/deals/refresh` - Trigger deal refresh/scraping

**Storage Layer:**
- Interface-based storage design (`IStorage`) for flexibility
- In-memory storage implementation (`MemStorage`) for development/testing
- Database-ready schema defined with Drizzle ORM for production deployment
- Support for PostgreSQL database with automatic UUID generation

**Data Model:**
- Deals table with comprehensive fields: title, platform, category, pricing, images, URLs, and timestamps
- Zod schemas for runtime validation and type safety
- Filtering schema supporting multiple criteria (platforms, categories, price ranges, discount thresholds)
- Pagination and sorting capabilities built into the data layer

### Database Schema

**Deals Table:**
- Primary key: UUID (auto-generated)
- Product information: title, category, image URL, deal URL
- Pricing: original price, discounted price, discount percentage
- Platform identification: amazon, flipkart, myntra, meesho
- Temporal data: expiration timestamp, scraped timestamp

**Design Decisions:**
- Integer pricing to avoid floating-point precision issues
- Nullable image URLs and expiration dates for flexibility
- Platform and category stored as text for extensibility
- Timestamps for deal lifecycle management

### External Dependencies

**Third-Party Services:**
- **Neon Database**: Serverless PostgreSQL database for production data storage
- **Unsplash**: Placeholder/demo images for deal cards

**Key NPM Packages:**
- **UI Components**: Radix UI primitives for accessible, unstyled components
- **Forms**: React Hook Form with Zod resolvers for validation
- **Styling**: Tailwind CSS with class-variance-authority for variant management
- **Date Handling**: date-fns for date formatting and manipulation
- **Carousel**: Embla Carousel for image galleries
- **Development**: Replit-specific plugins for enhanced development experience

**Web Scraping Service:**
- Mock scraping service implementation with placeholder data
- Designed for future integration with actual web scraping tools (Puppeteer/Cheerio)
- Automated deal refresh mechanism with configurable intervals
- Support for multiple e-commerce platforms with extensible architecture

### Development & Production

**Build Process:**
- Client: Vite builds React app to `dist/public`
- Server: esbuild bundles Express server to `dist/index.js`
- Shared schema and types between client and server via TypeScript path aliases

**Environment Configuration:**
- DATABASE_URL for PostgreSQL connection
- NODE_ENV for environment-specific behavior
- Drizzle migrations stored in `/migrations` directory

**Development Features:**
- Hot module replacement (HMR) via Vite
- TypeScript strict mode for type safety
- Request/response logging middleware
- Error overlay for runtime errors in development
- Replit-specific integrations (cartographer, dev banner) for enhanced IDE experience